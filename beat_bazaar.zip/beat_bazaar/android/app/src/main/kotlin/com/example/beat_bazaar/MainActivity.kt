package com.app.beatbaza

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
