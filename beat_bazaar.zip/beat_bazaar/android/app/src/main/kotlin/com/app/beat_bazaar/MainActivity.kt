package com.app.beat_bazaar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
